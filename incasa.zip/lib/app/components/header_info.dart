import 'package:flutter/foundation.dart';

class HeaderInfo with ChangeNotifier{

  String _nameUser = "";
  //Icon _icon;

  String get nameUser => _nameUser;

  //if (nameUser == null){
  //  nameUser = 'morador(a)';
  //}

  //if(isBlank(String nameUser).true){
  //  _nameUser = 'morador(a)!';
  //}


}