import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFFFE985);
const kTextColor = Colors.black;
const kBackgroundColor = Color(0xFFFFFFFF);

const double kDefPadding = 15.0;


